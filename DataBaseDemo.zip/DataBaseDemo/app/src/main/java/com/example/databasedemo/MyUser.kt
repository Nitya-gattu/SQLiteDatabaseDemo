package com.example.databasedemo

import android.text.Editable

data class MyUser(
    val name:String,
    val age: Int
)
