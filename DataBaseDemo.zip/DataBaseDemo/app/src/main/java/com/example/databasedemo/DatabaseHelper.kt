package com.example.databasedemo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.ContactsContract.Data

class DatabaseHelper(context:Context):SQLiteOpenHelper(
    context,
    DatabaseConstants.DATABASE_NAME,
    null,
    DatabaseConstants.DATABASE_VERSION
) {
    override fun onCreate(database: SQLiteDatabase?) {
        val createTableQuery = """
            CREATE TABLE ${DatabaseConstants.TABLE_NAME}(
            ${DatabaseConstants.COLUMN_ID} INTEGER PRIMARY KEY AUTOINCREMENT,
            ${DatabaseConstants.COLUMN_NAME} TEXT,
            ${DatabaseConstants.COLUMN_AGE} INTEGER
            )
        """.trimIndent()

        database!!.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun insertData(user: MyUser):Long{
        val values = ContentValues().apply {
            put(DatabaseConstants.COLUMN_NAME, user.name)
            put(DatabaseConstants.COLUMN_AGE, user.age)
        }
        return writableDatabase.insert(DatabaseConstants.TABLE_NAME, null, values)
    }

}