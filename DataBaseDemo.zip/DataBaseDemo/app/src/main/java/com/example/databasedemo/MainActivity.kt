package com.example.databasedemo

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.databasedemo.MyUser
import com.example.databasedemo.MyUserAdapter
import com.example.databasedemo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding
    private lateinit var userAdapter: MyUserAdapter
    val userDetails= mutableListOf<MyUser>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initview()
        inputdata()

    }

    @SuppressLint("NotifyDataSetChanged")
    private fun inputdata() {
        binding.save.setOnClickListener {
            val name = binding.userName.text.toString()
            val ageString = binding.userAge.text.toString()
            val age= ageString.toInt()
            userDetails.add(MyUser(name,age))
            binding.userAge.text.clear()
            binding.userName.text.clear()
            userAdapter.notifyDataSetChanged()
        }
    }

    private fun initview() {
        with(binding){
            recyclerview.layoutManager = LinearLayoutManager(this@MainActivity)
            userAdapter = MyUserAdapter(userDetails)
            recyclerview.adapter = userAdapter
        }

    }


}